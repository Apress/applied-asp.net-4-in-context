﻿
namespace TriathlonApp.Models.Domain {
    public class RankingSet {
        public int SwimRank { get; set; }
        public int CycleRank { get; set; }
        public int RunRank { get; set; }
        public int OverallRank { get; set; }
        public int RankCount { get; set; }
    }
}