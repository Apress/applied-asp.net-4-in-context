﻿using System.Collections.Generic;

namespace TriathlonApp.Models.Domain.Repository {

    public interface IRepository {

        IEnumerable<Event> Events { get; }
        void SaveEvent(Event ev);
        void DeleteEvent(Event ev);

        IEnumerable<EventType> EventTypes { get; }
        IEnumerable<ReferenceTime> ReferenceTimes { get; }
        IEnumerable<Athlete> Athletes { get; }

        RankingSet GetPersonalRank(Event ev);
        RankingSet GetReferenceRank(Event ev);
    }
}