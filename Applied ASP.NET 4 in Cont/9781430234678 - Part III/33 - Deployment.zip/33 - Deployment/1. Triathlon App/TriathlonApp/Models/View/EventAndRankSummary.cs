﻿using TriathlonApp.Models.Domain;

namespace TriathlonApp.Models.View {
    public class EventAndRankSummary {
        public Event Event { get; set; }
        public int PersonalRank {get; set;}
        public int ReferenceRank {get; set;}
    }
}