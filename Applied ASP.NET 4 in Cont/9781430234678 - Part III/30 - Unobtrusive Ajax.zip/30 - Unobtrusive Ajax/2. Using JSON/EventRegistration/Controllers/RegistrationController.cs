﻿using System;
using System.Linq;
using System.Web.Mvc;
using EventRegistration.Models.Domain;
using EventRegistration.Models.Domain.Repository;

namespace EventRegistration.Controllers {

    public class RegistrationController : Controller {
        private IRepository repository;

        public RegistrationController(IRepository repo) {
            repository = repo;
        }

        public ActionResult Index() {
            ViewBag.Competitions = repository.Competitions;
            return View(new Registration()); 
        }

        public JsonResult ValidateCity(string HomeCity) {
            string[] cities = { "London", "New York", "Boston", "San Francisco", "Paris" };
            if (Array.Exists(cities, x => x == HomeCity)) {
                return Json(true, JsonRequestBehavior.AllowGet);
            } else {
                return Json(string.Format("Residents of {0} cannot register", HomeCity),
                    JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public ActionResult HandleIndexPost(Registration registration) {

            if (ModelState.IsValidField("Name") && 
                repository.Registrations
                .Where(x => x.Name == registration.Name).Count() > 0) {

                ModelState.AddModelError("Name", 
                    "A registration has already been made in this name");
            }

            if (ModelState.IsValidField("Age") 
                && ModelState.IsValidField("CompetitionID")) {

                if (registration.Competition.Name == "Paris Panic" 
                    && registration.Age < 40) {

                    ModelState.AddModelError(string.Empty, 
                        "You must be at least 40 to do the Paris Panic");
                }
            }

            if (ModelState.IsValid) {
                repository.SaveRegistration(registration);
                return View("RegistrationComplete", registration);
            } else {
                ViewBag.Competitions = repository.Competitions;
                return View("Index", registration);
            }
        }
    }
}