﻿using System.Web.Mvc;
using EventRegistration.Infrastructure;
using System.ComponentModel.DataAnnotations;

namespace EventRegistration.Models.Domain {

    [ModelBinder(typeof(RegistrationModelBinder))]
    public class Registration {

        [Required]
        public int ID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string HomeCity { get; set; }

        [Required(ErrorMessage="Please enter an age")]
        [Range(18, 100, ErrorMessage = "Please enter an age between 18 and 100")]
        public int Age { get; set; }

        [Required]
        public int CompetitionID { get; set; }

        public virtual Competition Competition { get; set; }
    }
}