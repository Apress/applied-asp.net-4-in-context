﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace TriathlonApp.Models.Domain {
    public class Event {

        [HiddenInput(DisplayValue=false)]
        public int ID { get; set; }
        [DataType(DataType.Date)]
        public DateTime Date { get; set; }
        [Required]
        public string Athlete { get; set; }
        public string Type { get; set; }
        [Required]
        public TimeSpan SwimTime { get; set; }
        [Required]
        public TimeSpan CycleTime { get; set; }
        [Required]
        public TimeSpan RunTime { get; set; }
        [HiddenInput(DisplayValue=true)]
        public TimeSpan OverallTime { get; set; }
    }
}