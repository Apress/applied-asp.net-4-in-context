﻿using System.ComponentModel.DataAnnotations;

namespace TriathlonApp.Models.Domain {
    public class EventType {

        [Key]
        public string Name { get; set; }
        public float SwimMiles { get; set; }
        public float CycleMiles { get; set; }
        public float RunMiles { get; set; }
    }
}