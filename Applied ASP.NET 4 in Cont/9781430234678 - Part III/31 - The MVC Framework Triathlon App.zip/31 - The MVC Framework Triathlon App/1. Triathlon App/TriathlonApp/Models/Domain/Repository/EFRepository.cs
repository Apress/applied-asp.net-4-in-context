﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace TriathlonApp.Models.Domain.Repository {

    public class EFAdapter : DbContext {

        public EFAdapter(string connectionName)
            : base(connectionName) {
            // do nothing
        }

        public DbSet<Athlete> Athletes { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<EventType> EventTypes { get; set; }
        public DbSet<ReferenceTime> ReferenceTimes { get; set; }
    }

    public class EFRepository : IRepository {
        private EFAdapter adapter = new EFAdapter("EFRepository");

        public IEnumerable<Event> Events {
            get { return adapter.Events; }
        }

        public void SaveEvent(Event ev) {
            if (ev.ID == 0) {
                adapter.Events.Add(ev);
            } else {
                Event rev = Events.Where(x => x.ID == ev.ID).FirstOrDefault();
                if (rev.ID > 0) {
                    rev.Date = ev.Date;
                    rev.Athlete = ev.Athlete;
                    rev.Type = ev.Type;
                    rev.SwimTime = ev.SwimTime;
                    rev.CycleTime = ev.CycleTime;
                    rev.RunTime = ev.RunTime;
                    rev.OverallTime = ev.OverallTime;
                }
            }
            adapter.SaveChanges();
        }

        public void DeleteEvent(Event ev) {
            Event rev = Events.Where(x => x.ID == ev.ID).FirstOrDefault();
            if (rev.ID > 0) {
                adapter.Events.Remove(rev);
                adapter.SaveChanges();
            }
        }

        public IEnumerable<EventType> EventTypes {
            get { return adapter.EventTypes; }
        }

        public IEnumerable<ReferenceTime> ReferenceTimes {
            get { return adapter.ReferenceTimes; }
        }

        public IEnumerable<Athlete> Athletes {
            get { return adapter.Athletes; }
        }

        public RankingSet GetPersonalRank(Event ev) {

            IEnumerable<Event> interimResults = adapter.Events
                .Where(x => x.Athlete == ev.Athlete && x.Type == ev.Type);

            return new RankingSet {
                SwimRank = interimResults.Count(x => x.SwimTime <= ev.SwimTime),
                CycleRank = interimResults.Count(x => x.CycleTime <= ev.CycleTime),
                RunRank = interimResults.Count(x => x.RunTime <= ev.RunTime),
                OverallRank = interimResults.Count(x => x.OverallTime <= ev.OverallTime),
                RankCount = interimResults.Count()
            };
        }

        public RankingSet GetReferenceRank(Event ev) {

            IEnumerable<ReferenceTime> interimResults = adapter.ReferenceTimes
                .Where(x => x.Type == ev.Type);

            return new RankingSet {
                SwimRank = interimResults
                            .Where(x => x.SwimTime >= ev.SwimTime).Min(x => x.SwimPos),
                CycleRank = interimResults
                             .Where(x => x.CycleTime >= ev.CycleTime).Min(x => x.CyclePos),
                RunRank = interimResults
                            .Where(x => x.RunTime >= ev.RunTime).Min(x => x.RunPos),
                OverallRank = interimResults
                            .Where(x => x.OverallTime >= ev.OverallTime)
                            .Min(x => x.OverallPos),
                RankCount = interimResults.Count()
            };
        }
    }
}
