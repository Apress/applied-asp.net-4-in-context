﻿using System.ComponentModel.DataAnnotations;

namespace TriathlonApp.Models.Domain {
    public class Athlete {

        [Key]
        public string Name { get; set; }
    }
}