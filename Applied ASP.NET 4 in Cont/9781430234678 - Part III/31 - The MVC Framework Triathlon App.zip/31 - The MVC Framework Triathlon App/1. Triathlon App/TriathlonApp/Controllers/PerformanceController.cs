﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using TriathlonApp.Models.Domain;
using TriathlonApp.Models.Domain.Repository;
using TriathlonApp.Models.View;

namespace TriathlonApp.Controllers {
    public class PerformanceController : Controller {
        private IRepository repository;

        public PerformanceController(IRepository repo) {
            repository = repo;   
        }

        public ActionResult Index(string athlete) {

            if (string.IsNullOrEmpty(athlete)) {
                athlete = repository.Athletes.First().Name;
            }

            PerformanceSummary data = new PerformanceSummary {
                Athlete = athlete,
                SprintTimes = GetTimeData(athlete, "Sprint"),
                OlympicTimes = GetTimeData(athlete, "Olympic")
            };
            
            data.OlympicRanks = GetRankData("Olympic", data.OlympicTimes);
            data.SprintRanks = GetRankData("Sprint", data.SprintTimes);

            ViewBag.Athletes = repository.Athletes.Select(x => x.Name);

            if (Request.IsAjaxRequest()) {
                return PartialView("PerformanceTable", data);
            } else {
                return View(data);
            }
        }

        private TimeSet GetTimeData(string athlete, string eventType) {

            TimeSet result = new TimeSet();

            IEnumerable<Event> events = repository.Events
                .Where(x => x.Athlete == athlete && x.Type == eventType);

            if (events.Count() > 0) {
                result.SwimTime = events.Min(x => x.SwimTime);
                result.CycleTime = events.Min(x => x.CycleTime);
                result.RunTime = events.Min(x => x.RunTime);
                result.OverallTime = events.Min(x => x.OverallTime);
            }

            return result;
        }

        private RankingSet GetRankData(string eventType, TimeSet times) {

            if (times.SwimTime == TimeSpan.Zero || times.CycleTime == TimeSpan.Zero
                || times.RunTime == TimeSpan.Zero || times.OverallTime == TimeSpan.Zero) {
                return new RankingSet();
            } else {
                return repository.GetReferenceRank(new Event {
                    Type = eventType,
                    SwimTime = times.SwimTime,
                    CycleTime = times.CycleTime,
                    RunTime = times.RunTime,
                    OverallTime = times.OverallTime
                });
            }
        }
    }
}
