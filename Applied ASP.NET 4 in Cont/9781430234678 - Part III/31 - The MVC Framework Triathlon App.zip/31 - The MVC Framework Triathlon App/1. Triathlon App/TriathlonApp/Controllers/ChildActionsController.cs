﻿using System;
using System.Linq;
using System.Web.Mvc;
using TriathlonApp.Models.Domain;
using TriathlonApp.Models.Domain.Repository;

namespace TriathlonApp.Controllers {
    public class ChildActionsController : Controller {
        private IRepository repository;

        public ChildActionsController(IRepository repo) {
            repository = repo;
        }

        [ChildActionOnly]
        public string FooterMessage() {

            float distance = repository.Events
                .GroupBy(x => x.Type)
                .Aggregate(0f, (sum, egroup) => {
                   EventType etype = repository.EventTypes.First(x => x.Name == egroup.Key);
                   return sum += egroup.Count() * 
                       (etype.SwimMiles + etype.CycleMiles + etype.RunMiles);
                });

            TimeSpan time = repository.Events.Select(x => x.OverallTime)
                .Aggregate(TimeSpan.Zero, (total, newtime) => total.Add(newtime));

            return string.Format("{0} Events, {1:F1} Miles, {2} Hours and {3} Minutes",
                    repository.Events.Count(), distance, time.Hours, time.Minutes);
        }
    }
}
