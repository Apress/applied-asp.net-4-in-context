﻿using System.Web.Mvc;
using System.Web.Security;
using TriathlonApp.Models.View;

namespace TriathlonApp.Controllers {
    public class AccountController : Controller {

        public ActionResult LogOn() {
            return View();
        }

        [HttpPost]
        public ActionResult LogOn(LogOnViewModel creds, string returnURL) {
            if (ModelState.IsValid) {
                if (FormsAuthentication.Authenticate(creds.UserName, creds.Password)) {
                    FormsAuthentication.SetAuthCookie(creds.UserName, false);
                    return Redirect(returnURL ?? Url.Action("Index", "Event"));
                } else {
                    ModelState.AddModelError("", "Incorrect username or password");
                }
            }
            return View(creds);                    
        }
    }
}
