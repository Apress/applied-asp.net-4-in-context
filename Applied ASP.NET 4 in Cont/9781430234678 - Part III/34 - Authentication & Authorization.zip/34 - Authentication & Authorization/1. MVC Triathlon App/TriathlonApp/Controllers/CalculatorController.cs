﻿using System.Web.Mvc;
using TriathlonApp.Models.Domain.Repository;
using TriathlonApp.Models.View;

namespace TriathlonApp.Controllers {
    public class CalculatorController : Controller {
        private const float metersToMiles = 0.00062137119223733f;
        private const float minsPerHour = 60f;
        private IRepository repository;

        public CalculatorController(IRepository repo) {
            repository = repo;
        }

        public ActionResult Index() {
            return View(new CalcData());
        }

        [HttpPost]
        public ActionResult Index(CalcData calcData) {
            if (ModelState.IsValid) {
                calcData.Result = new CalcResult {
                    Distance = (calcData.Laps * calcData.PoolLength) * metersToMiles,
                    CaloriesBurned = (int)((calcData.Minutes / minsPerHour) 
                        * calcData.CalsPerHour),
                    Pace = (int)((calcData.Minutes * minsPerHour) / calcData.Laps),
                };
            }
            return View(calcData);
        }
    }
}
