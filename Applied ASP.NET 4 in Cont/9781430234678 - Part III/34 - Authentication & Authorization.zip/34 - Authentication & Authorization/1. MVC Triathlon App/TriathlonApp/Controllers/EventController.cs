﻿using System;
using System.Linq;
using System.Web.Mvc;
using TriathlonApp.Models.Domain;
using TriathlonApp.Models.Domain.Repository;
using TriathlonApp.Models.View;

namespace TriathlonApp.Controllers {

    [Authorize]
    public class EventController : Controller {
        private IRepository repository;

        public EventController(IRepository repo) {
            repository = repo;
        }

        public ActionResult Index(string eventFilter = "All") {

            var selectedEvents = (eventFilter == "All" ? repository.Events 
                : repository.Events.Where(x => x.Type == eventFilter))
                .Select(x =>
                    new EventAndRankSummary {
                        Event = x,
                        PersonalRank = repository.GetPersonalRank(x).OverallRank,
                        ReferenceRank = repository.GetReferenceRank(x).OverallRank
                });

            if (Request.IsAjaxRequest()) {
                return PartialView("EventsTable", selectedEvents);
            } else {
                ViewBag.EventTypes 
                   = new string[] {"All"}.Concat(repository.EventTypes.Select(x => x.Name));
                return View(selectedEvents);
            }
        }

        public ActionResult Add() {
            ViewBag.EventTypes = repository.EventTypes.Select(x => x.Name);
            ViewBag.Athletes = repository.Athletes.Select(x => x.Name);
            return View(new Event { Date = DateTime.Now });
        }

        [HttpPost]
        public ActionResult Add(Event ev) {

            ValidateEvent(ev);

            if (ModelState.IsValid) {
                ev.OverallTime = ev.SwimTime + ev.CycleTime + ev.RunTime;
                repository.SaveEvent(ev);
                return RedirectToAction("Index");
            } else {
                ViewBag.EventTypes = repository.EventTypes.Select(x => x.Name);
                ViewBag.Athletes = repository.Athletes.Select(x => x.Name);
                return View(ev);
            }
        }

        public ActionResult Edit(int id) {
            ViewBag.EventTypes = repository.EventTypes.Select(x => x.Name);
            ViewBag.Athletes = repository.Athletes.Select(x => x.Name);
            Event ev = repository.Events.Where(x => x.ID == id).FirstOrDefault();
            if (ev.ID > 0) {
                return View(ev);
            } else {
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public ActionResult Edit(Event ev) {
            ValidateEvent(ev);
            if (ModelState.IsValid) {
                ev.OverallTime = ev.SwimTime + ev.CycleTime + ev.RunTime;
                repository.SaveEvent(ev);
                return RedirectToAction("Index");
            } else {
                return View(ev);
            }
        }

        public ActionResult Delete(int id) {
            Event ev = repository.Events.Where(x => x.ID == id).FirstOrDefault();
            if (ev.ID > 0) {
                return View(ev);
            } else {
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public ActionResult Delete(Event ev) {
            repository.DeleteEvent(ev);
            return RedirectToAction("Index");
        }

        private void ValidateEvent(Event ev) {
            if (ModelState.IsValidField("SwimTime") && ev.SwimTime == TimeSpan.Zero) {
                ModelState.AddModelError("SwimTime", "Enter a time");
            }
            if (ModelState.IsValidField("CycleTime") && ev.CycleTime == TimeSpan.Zero) {
                ModelState.AddModelError("CycleTime", "Enter a time");
            }
            if (ModelState.IsValidField("RunTime") && ev.RunTime == TimeSpan.Zero) {
                ModelState.AddModelError("RunTime", "Enter a time");
            }
        }
    }
}