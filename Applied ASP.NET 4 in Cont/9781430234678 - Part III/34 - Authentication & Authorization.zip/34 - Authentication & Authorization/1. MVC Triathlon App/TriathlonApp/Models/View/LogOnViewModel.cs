﻿using System.ComponentModel.DataAnnotations;

namespace TriathlonApp.Models.View {
    public class LogOnViewModel {

        [Required]
        public string UserName { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}