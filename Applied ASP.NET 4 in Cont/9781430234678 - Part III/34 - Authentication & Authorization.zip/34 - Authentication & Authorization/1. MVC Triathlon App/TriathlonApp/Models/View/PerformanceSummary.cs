﻿using System;
using TriathlonApp.Models.Domain;

namespace TriathlonApp.Models.View {

    public class PerformanceSummary {
        public string Athlete { get; set; }
        public RankingSet SprintRanks { get; set; }
        public TimeSet SprintTimes { get; set; }
        public RankingSet OlympicRanks { get; set; }
        public TimeSet OlympicTimes { get; set; }
    }

    public class TimeSet {
        public TimeSpan SwimTime { get; set; }
        public TimeSpan CycleTime { get; set; }
        public TimeSpan RunTime { get; set; }
        public TimeSpan OverallTime { get; set; }
    }
}