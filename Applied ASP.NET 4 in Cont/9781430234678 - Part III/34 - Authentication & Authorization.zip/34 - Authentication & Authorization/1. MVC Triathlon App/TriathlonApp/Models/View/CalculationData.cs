﻿
using System.ComponentModel.DataAnnotations;
namespace TriathlonApp.Models.View {

    public class CalcData {

        public CalcData() {
            Laps = 80;
            PoolLength = 20;
            Minutes = 60;
            CalsPerHour = 1070;
        }

        [Required]
        [Range(1, 500)]
        public int Laps { get; set; }
        [Required]
        [Range(10, 500)]
        public int PoolLength { get; set; }
        [Required]
        [Range(1, 500)]
        public int Minutes { get; set; }
        [Required]
        [Range(1, 5000)]
        public int CalsPerHour {get; set;}

        public CalcResult Result { get; set; }
    }

    public class CalcResult {
        public float Distance { get; set; }
        public int CaloriesBurned { get; set; }
        public int Pace { get; set; }
    }
}