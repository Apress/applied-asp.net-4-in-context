﻿using System;

namespace TriathlonApp.Models.Domain {
    public class ReferenceTime {

        public int ID { get; set; }
        public int OverallPos { get; set; }
        public TimeSpan OverallTime { get; set; }
        public int SwimPos { get; set; }
        public TimeSpan SwimTime { get; set; }
        public int CyclePos { get; set; }
        public TimeSpan CycleTime { get; set; }
        public int RunPos { get; set; }
        public TimeSpan RunTime { get; set; }
        public string Type { get; set; }
    }
}