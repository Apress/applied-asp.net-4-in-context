﻿using System;

namespace TriathlonApp {
    public partial class Calculator : System.Web.UI.Page {
        private const float metersToMiles = 0.00062137119223733f;
        private const float minsPerHour = 60f;

        protected void Page_Load(object sender, EventArgs e) {

            if (IsPostBack) {

                // parse the input values
                int laps = int.Parse(LapsTextBox.Text);
                int length = int.Parse(LengthTextBox.Text);
                int minutes = int.Parse(MinutesTextBox.Text);
                int calories = int.Parse(CaloriesTextBox.Text);

                // perform the calculation and set the result values
                DistanceLabel.Text = ((laps * length) * metersToMiles).ToString("F2");
                CalsLabel.Text = ((minutes / minsPerHour) * calories).ToString("F0");
                PaceLabel.Text = ((minutes * minsPerHour) / laps).ToString("F0");

                // make the results table visible
                ResultsTable.Visible = true;
            }
        }
    }
}