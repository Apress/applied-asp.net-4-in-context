﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;

namespace TriathlonApp {
    public partial class Performance : System.Web.UI.Page {

        private void ProcessFieldSet(TrainingDataEntities entities, string athlete, 
            string eventType, Label[] personaLabels, Label[] overallLabels) {

            Event bestTimes = new Event();
            IEnumerable<Event> classEvents = entities.Events.Where(e => e.Athlete == athlete && e.Type == eventType);

            if (classEvents.Count() > 0) {

                bestTimes.SwimTime = classEvents.Select(e => e.SwimTime).Min();
                bestTimes.CycleTime = classEvents.Select(e => e.CycleTime).Min();
                bestTimes.RunTime = classEvents.Select(e => e.RunTime).Min();
                bestTimes.OverallTime = classEvents.Select(e => e.OverallTime).Min();

                personaLabels[0].Text = bestTimes.SwimTime.ToString();
                personaLabels[1].Text = bestTimes.CycleTime.ToString();
                personaLabels[2].Text = bestTimes.RunTime.ToString();
                personaLabels[3].Text = bestTimes.OverallTime.ToString();

                // get the ranking for the sprint events
                IEnumerable<Ranking> ranks = entities.GetReferenceRanking(eventType,
                    bestTimes.SwimTime, bestTimes.CycleTime,
                    bestTimes.RunTime, bestTimes.OverallTime);

                foreach (Ranking rank in ranks) {
                    switch (rank.Activity) {
                        case "Swim":
                            overallLabels[0].Text = rank.Pos.ToString();
                            break;
                        case "Cycle":
                            overallLabels[1].Text = rank.Pos.ToString();
                            break;
                        case "Run":
                            overallLabels[2].Text = rank.Pos.ToString();
                            break;
                        case "Overall":
                            overallLabels[3].Text = rank.Pos.ToString();
                            break;
                    }
                }

            } else {
                foreach (Label lab in personaLabels.Concat(overallLabels)) {
                    lab.Text = "--";
                }
            }
        }

        protected void Page_Load(object sender, EventArgs args) {

            using (TrainingDataEntities entities = new TrainingDataEntities()) {

                // get the selected athlete
                string athlete = DropDownList1.SelectedValue;
                if (string.IsNullOrEmpty(athlete)) {
                    athlete = entities.Athletes.First().Name;
                }

                ProcessFieldSet(entities, athlete, "Sprint",
                    new Label[] { sbstLabel, sbctLabel, sbrtLabel, sbotLabel },
                    new Label[] { sbsrLabel, sbcrLabel, sbrrLabel, sborLabel });

                ProcessFieldSet(entities, athlete, "Olympic",
                  new Label[] { obstLabel, obctLabel, obrtLabel, obotLabel  },
                  new Label[] { obsrLabel, obcrLabel, obrrLabel, oborLabel  });
            }
        }
    }
}