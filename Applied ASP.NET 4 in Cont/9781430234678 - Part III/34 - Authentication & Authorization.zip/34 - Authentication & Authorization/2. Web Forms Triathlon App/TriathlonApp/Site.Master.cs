﻿using System;
using System.Linq;

namespace TriathlonApp {
    public partial class Site : System.Web.UI.MasterPage {

        protected void Page_Load(object sender, EventArgs e) {

            using (TrainingDataEntities entities = new TrainingDataEntities()) {

                int eventCount = entities.Events.Count();
                TimeSpan time = new TimeSpan();
                float distance = 0;

                foreach (EventType ev in entities.Events.Select(ev => ev.EventType)) {
                    distance += (ev.SwimMiles + ev.CycleMiles + ev.RunMiles);
                }

                foreach (TimeSpan ts in entities.Events.Select(ev => ev.OverallTime)) {
                    time += ts;
                }

                footerLabel.Text 
                    = string.Format("{0} Events, {1:F1} Miles, {2} Hours and {3} Minutes",
                    eventCount.ToString(), distance, time.Hours, time.Minutes);
            }
        }

        protected void HandleTabChange(object sender, TabSelectedEventArgs e) {
            Response.Redirect(string.Format("~/{0}.aspx", e.SelectedTab));
        }
    }
}