﻿using System;
using System.Web.UI.WebControls;

namespace TriathlonApp {

    public class TabSelectedEventArgs : EventArgs {
        public string SelectedTab { get; set; }
    }

    public partial class TabButtons : System.Web.UI.UserControl {
        public event EventHandler<TabSelectedEventArgs> TabSelectionChanged;

        protected void Page_Load(object sender, EventArgs e) {
            switch (Request.FilePath) {
                case "/Events.aspx":
                    EventButton.ImageUrl = "~/Images/btn-on-event.png";
                    break;
                case "/Performance.aspx":
                    PerfButton.ImageUrl = "~/Images/btn-on-perf.png";
                    break;
                case "/Calculator.aspx":
                    CalcButton.ImageUrl = "~/Images/btn-on-calc.png";
                    break;
            }
        }

        protected override bool OnBubbleEvent(object source, EventArgs args) {

            if (args is CommandEventArgs) {
                CommandEventArgs ce = (CommandEventArgs)args;
                if (ce.CommandName == "Tab" && TabSelectionChanged != null) {
                    TabSelectionChanged(this, 
                            new TabSelectedEventArgs { 
                                SelectedTab = ce.CommandArgument.ToString()
                            });
                    return true;
                }
            }
            return false;
        }
    }
}