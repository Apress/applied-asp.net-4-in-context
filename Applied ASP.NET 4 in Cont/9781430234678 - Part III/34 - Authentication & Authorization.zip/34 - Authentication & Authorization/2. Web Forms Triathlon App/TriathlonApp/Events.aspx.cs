﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TriathlonApp {
    public partial class Events : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs args) {

            using (TrainingDataEntities entities = new TrainingDataEntities()) {

                if (!IsPostBack) {
                    DropDownList1.DataSource
                        = new[] { "All" }.Concat(entities.EventTypes.Select(e => e.Name));
                }

                string selectedEventType
                    = string.IsNullOrEmpty(DropDownList1.SelectedValue)
                        ? "All" : DropDownList1.SelectedValue;

                IEnumerable<Event> events = selectedEventType == "All" ?
                    entities.Events :
                        entities.Events.Where(e => e.Type == selectedEventType);

                DataList1.DataSource = events.Select(e => new {
                    e.ID,
                    e.Date,
                    e.Athlete,
                    e.Type,
                    e.SwimTime,
                    e.CycleTime,
                    e.RunTime,
                    e.OverallTime,
                    PRank = entities.GetPersonalRanking(e.Athlete, e.Type, e.SwimTime,
                        e.CycleTime, e.RunTime, e.OverallTime)
                        .Where(r => r.Activity == "Overall")
                        .Select(r => r.Pos).FirstOrDefault(),
                    RRank = entities.GetReferenceRanking(e.Type, e.SwimTime, e.CycleTime,
                        e.RunTime, e.OverallTime)
                        .Where(r => r.Activity == "Overall")
                        .Select(r => r.Pos).FirstOrDefault()
                });

                DataBind();
            }
        }
    }
}