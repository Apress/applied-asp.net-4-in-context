﻿using System;
using System.Web.UI.WebControls;

namespace TriathlonApp {
    public partial class EventEditor : System.Web.UI.Page {
        private string mode;

        protected void Page_Load(object sender, EventArgs e) {

            mode = Request.QueryString["mode"];
            string id =  Request.QueryString["id"];

            if (string.IsNullOrEmpty(mode)) {
                Response.Redirect("~/Events.aspx");
            } else {
                if (mode == "add") {
                    FormView1.ChangeMode(FormViewMode.Insert);
                } else if (mode == "edit" || mode == "delete") {
                    EntityDataSource1.Where = "it.ID = " + id;
                    FormView1.ChangeMode(FormViewMode.Edit);
                }
            }
        }

        protected void Page_PreRender(object sender, EventArgs e) {
            if (mode == "edit" || mode == "delete") {
                FormView1.FindControl("EditButton").Visible = mode == "edit";
                FormView1.FindControl("DeleteButton").Visible = mode == "delete";
            }
        }

        protected void ItemChanged(object sender, EventArgs e) {
            Response.Redirect("~/Events.aspx");
        }
    }
}