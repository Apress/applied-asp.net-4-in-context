﻿using System.Web.Mvc;
using EventRegistration.Models.Domain.Repository;
using System;

namespace EventRegistration.Controllers {

    public class ReportsController : Controller {
        private IRepository repository;

        public ReportsController(IRepository repo) {
            repository = repo;
        }

        [HandleError(ExceptionType=typeof(FormatException), View="CustomError")]
        public ActionResult Index() {
            return View();
        }

        [HttpPost]
        public ActionResult Index(string report) {
            switch (report) {
                case "Competitions":
                    return View("CompetitionReport", repository.Competitions);
                case "Registrations":
                    return View("RegistrationReport", repository.Registrations);
                default:
                    return View();
            }
        }
    }
}
