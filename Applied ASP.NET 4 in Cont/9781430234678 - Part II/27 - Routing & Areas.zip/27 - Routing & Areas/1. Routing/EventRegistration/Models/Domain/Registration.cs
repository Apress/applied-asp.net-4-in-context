﻿
namespace EventRegistration.Models.Domain {
    public class Registration {

        public int ID { get; set; }

        public string Name { get; set; }
        public string HomeCity { get; set; }
        public int Age { get; set; }

        public int CompetitionID { get; set; }

        public virtual Competition Competition {get; set;}
    }
}