﻿using System.Linq;
using System.Web.Mvc;
using EventRegistration.Models.Domain;
using EventRegistration.Models.Domain.Repository;

namespace EventRegistration.Infrastructure {
    public class RegistrationModelBinder : DefaultModelBinder {
        
        public override object BindModel(ControllerContext controllerContext, 
            ModelBindingContext bindingContext) {

            Registration reg = (Registration)base.BindModel(controllerContext, 
                bindingContext);

            reg.ID = int.Parse(GetValue(bindingContext, "ID", "0"));

            IRepository repo = DependencyResolver.Current.GetService<IRepository>();

            reg.Competition = repo.Competitions
                .Where(x => x.ID == reg.CompetitionID).FirstOrDefault();

            return reg;
        }

        private string GetValue(ModelBindingContext context, string key,
            string defaultValue = null) {

            ValueProviderResult vpr = context.ValueProvider.GetValue(key);
            return vpr == null ? defaultValue : vpr.AttemptedValue;
        }
    }
}