﻿using System.Linq;
using System.Web.Mvc;
using EventRegistration.Models.Domain;
using EventRegistration.Models.Domain.Repository;

namespace EventRegistration.Infrastructure {
    public class RegistrationModelBinder : IModelBinder {
        
        public object BindModel(ControllerContext controllerContext, 
            ModelBindingContext bindingContext) {

            Registration reg = new Registration();

            reg.ID = int.Parse(GetValue(bindingContext, "ID", "0"));
            reg.Name = GetValue(bindingContext, "Name");
            reg.Age = int.Parse(GetValue(bindingContext, "Age"));
            reg.HomeCity = GetValue(bindingContext, "HomeCity");
            reg.CompetitionID = int.Parse(GetValue(bindingContext, "CompetitionID"));

            IRepository repo = DependencyResolver.Current.GetService<IRepository>();

            reg.Competition = repo.Competitions
                .Where(x => x.ID == reg.CompetitionID).FirstOrDefault();

            return reg;
        }

        private string GetValue(ModelBindingContext context, string key, 
            string defaultValue = null) {

            ValueProviderResult vpr = context.ValueProvider.GetValue(key);
            return vpr == null ? defaultValue: vpr.AttemptedValue;
        }
    }
}