﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using EventRegistration.Models.Domain;
using EventRegistration.Models.Domain.Repository;
using EventRegistration.Models.View;

namespace EventRegistration.Controllers {

    public class CompetitionController : Controller {
        private IRepository repository;

        public CompetitionController(IRepository repo) {
            repository = repo;
        }

        public ActionResult Index() {
            return View(repository.Competitions);
        }

        public ViewResult Registrants() {
            IList<CompetitionNames> names = new List<CompetitionNames>();
            foreach (Competition comp in repository.Competitions) {
                names.Add(new CompetitionNames {
                    EventName = comp.Name,
                    RegistrantNames = comp.Registrations.Select(e => e.Name).Distinct()
                });
            }
            return View(names);
        }

        [ChildActionOnly]
        public PartialViewResult Footer() {
            ViewBag.CompCount = repository.Competitions.Count();
            ViewBag.RegCount = repository.Registrations.Count();
            return PartialView(DateTime.Now);
        }

        public void NoFurtherAction() {
            foreach (Competition comp in repository.Competitions.ToArray()) {
                comp.Date = comp.Date.AddMonths(1);
                repository.SaveCompetition(comp);
            }
        }

        public string Time() {
            return string.Format("The time is: {0}", DateTime.Now.ToShortTimeString());                
        }
    }
}