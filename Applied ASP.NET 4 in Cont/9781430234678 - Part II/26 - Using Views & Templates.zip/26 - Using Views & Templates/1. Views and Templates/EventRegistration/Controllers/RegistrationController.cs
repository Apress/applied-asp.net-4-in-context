﻿using System;
using System.Linq;
using System.Web.Mvc;
using EventRegistration.Models.Domain;
using EventRegistration.Models.Domain.Repository;

namespace EventRegistration.Controllers {

    public class RegistrationController : Controller {
        private IRepository repository;

        public RegistrationController(IRepository repo) {
            repository = repo;
        }

        public ActionResult Index() {
            ViewBag.Competitions = repository.Competitions;
            return View();
        }

        [HttpPost]
        public ActionResult Index(Registration registration) {
            repository.SaveRegistration(registration);
            return View("RegistrationComplete", registration);
        }

        public ActionResult List() {

            ViewBag.Time = DateTime.Now;

            //var results = repository.Registrations
            //    .Join(repository.Competitions, reg => reg.CompetitionID, comp => comp.ID,
            //    (reg, comp) => new { Reg = reg, Comp = comp })
            //    .ToArray()
            //    .Select(e => {
            //        e.Reg.Competition = e.Comp;
            //        return e.Reg;
            //    });

            return View(repository.Registrations);
        }

        public ActionResult Test() {
            return View(repository.Registrations.First());
        }
    }
}