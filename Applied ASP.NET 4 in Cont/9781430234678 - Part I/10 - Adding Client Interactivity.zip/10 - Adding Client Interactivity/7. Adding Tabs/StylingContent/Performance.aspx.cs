﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace StylingContent {

    public partial class Performance : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            using (TrainingDataEntities context = new TrainingDataEntities()) {

                // define the athlete name - this is a 
                // placeholder for a feature in a later chapter
                string athleteName = "Adam Freeman";


                // get the best times for the sprint distance
                Event bestTimes = DataAccess.GetBestTimes(context, athleteName, "Sprint");

                this.sprintSwimTime.InnerText = bestTimes.SwimTime.ToString();
                this.sprintCycleTime.InnerText = bestTimes.CycleTime.ToString();
                this.sprintRunTime.InnerText = bestTimes.RunTime.ToString();
                this.sprintOverallTime.InnerText = bestTimes.OverallTime.ToString();

                // get the rankings for the best times
                RankingSet ranks = DataAccess.GetReferenceRanking(context, bestTimes);
                this.sprintSwimRank.InnerText = ranks.SwimRank.ToString();
                this.sprintCycleRank.InnerText = ranks.CycleRank.ToString();
                this.sprintRunRank.InnerText = ranks.RunRank.ToString();
                this.sprintOverallRank.InnerText = ranks.OverallRank.ToString(); 

                // get the best times for the olympic distance
                bestTimes = DataAccess.GetBestTimes(context, athleteName, "Olympic");

                this.olympicSwimTime.InnerText = bestTimes.SwimTime.ToString();
                this.olympicCycleTime.InnerText = bestTimes.CycleTime.ToString();
                this.olympicRunTime.InnerText = bestTimes.RunTime.ToString();
                this.olympicOverallTime.InnerText = bestTimes.OverallTime.ToString();

                // get the rankings for the best times
                ranks = DataAccess.GetReferenceRanking(context, bestTimes);
                this.olympicSwimRank.InnerText = ranks.SwimRank.ToString();
                this.olympicCycleRank.InnerText = ranks.CycleRank.ToString();
                this.olympicRunRank.InnerText = ranks.RunRank.ToString();
                this.olympicOverallRank.InnerText = ranks.OverallRank.ToString(); 

            }
        }
    }
}