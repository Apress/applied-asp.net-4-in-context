﻿using System;

namespace StylingContent {

    public partial class SiteMaster : System.Web.UI.MasterPage {

        protected void Page_Load(object sender, EventArgs e) {

            using (TrainingDataEntities context = new TrainingDataEntities()) {
                // get the total data from the database
                DataTotals totals = DataAccess.GetDataTotals(context);
                // use the totals to update the span contents for the footer
                eventCountSpan.InnerText = totals.EventTotal.ToString();
                mileCountSpan.InnerText = string.Format("{0:F1}", totals.MileTotal);
                hourCountSpan.InnerText = string.Format("{0} Hours and {1} Minutes", 
                    totals.TimeTotal.Hours, totals.TimeTotal.Minutes); ;

            }

           // eventCountSpan.InnerText = Request.Path;

        }
    }
}
