﻿using System.Linq;
using System.Web.Mvc;
using EventRegistration.Models.Domain.Repository;
using EventRegistration.Models.Domain;

namespace EventRegistration.Controllers {

    public class RegistrationController : Controller {
        private IRepository repository;

        public RegistrationController(IRepository repo) {

            repository = repo;
        }

        public ActionResult Index() {
            ViewBag.Competitions = repository.Competitions.Select(e => e.Name);
            return View();
        }

        [HttpPost]
        public ActionResult Index(Registration registration, string competition) {

            registration.Competition = repository.Competitions
                .Where(e => e.Name == competition).FirstOrDefault();

            repository.SaveRegistration(registration);
            return View("RegistrationComplete", registration);
        }
    }
}