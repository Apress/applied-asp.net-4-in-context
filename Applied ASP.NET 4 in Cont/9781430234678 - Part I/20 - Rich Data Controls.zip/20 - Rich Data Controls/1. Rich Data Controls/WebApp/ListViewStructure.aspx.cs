﻿using System;

namespace WebApp {
    public partial class ListViewStructure : System.Web.UI.Page {
        public StringAdapter[] DataItems = new[] { 
            new StringAdapter {Name = "Item 01"}, new StringAdapter {Name = "Item 02"},
            new StringAdapter {Name = "Item 03"}, new StringAdapter {Name = "Item 04"},
            new StringAdapter {Name = "Item 05"}};
       
        protected void Page_Load(object sender, EventArgs e) {

        }
    }

    public class StringAdapter {

        public string Name { get; set; }
    }
}