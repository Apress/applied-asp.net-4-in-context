﻿using System;

namespace WebApp {
    public partial class DataListSelect : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }

        protected void DataList1_SelectedIndexChanged(object sender, EventArgs e) {
            DataList1.DataBind();
        }
    }
}