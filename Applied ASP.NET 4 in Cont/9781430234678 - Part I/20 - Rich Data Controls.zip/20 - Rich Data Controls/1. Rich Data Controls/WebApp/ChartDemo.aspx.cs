﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WebApp {
    public partial class ChartDemo : System.Web.UI.Page {
        public IEnumerable<EventWrapper> Results = new TrainingDataEntities().Events
            .Select(e => new {
                Date = e.Date,
                Time = e.OverallTime,
                Distance = e.EventType.SwimMiles + e.EventType.CycleMiles + e.EventType.RunMiles
            })
            .ToArray()
            .Select(e => new EventWrapper() { 
                Date = e.Date, 
                Hours = e.Time.TotalHours,
                Distance = e.Distance
            });

        protected void Page_Load(object sender, EventArgs e) {
        }
    }

    public class EventWrapper {
        public DateTime Date { get; set; }
        public double Hours { get; set; }
        public float Distance { get; set; }
    }

}