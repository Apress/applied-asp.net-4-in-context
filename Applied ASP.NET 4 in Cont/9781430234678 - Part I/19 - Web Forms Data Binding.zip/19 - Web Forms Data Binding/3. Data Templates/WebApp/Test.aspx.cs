﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp {
    public partial class Test : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

            
        }

        

        protected override bool OnBubbleEvent(object sender, EventArgs e) {

            if (e is CommandEventArgs) {

                CommandEventArgs ce = (CommandEventArgs)e;
                results.InnerText = String.Format("Command: {0}, Argument: {1}", ce.CommandName, ce.CommandArgument);

            }

            return true;
        }
    }
}