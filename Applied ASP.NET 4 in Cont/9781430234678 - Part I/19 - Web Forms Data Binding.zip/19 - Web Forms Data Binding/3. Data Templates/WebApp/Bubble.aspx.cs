﻿using System;
using System.Web.UI.WebControls;

namespace WebApp {
    public partial class Bubble : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }

        protected override bool OnBubbleEvent(object source, EventArgs args) {
            if (args is CommandEventArgs) {
                CommandEventArgs ce = (CommandEventArgs)args;

                Label1.Text = String.Format("Command Name: {0}, Command Argument: {1}", 
                    ce.CommandName, ce.CommandArgument);

                return true;
            }
            return false;
        }
    }
}