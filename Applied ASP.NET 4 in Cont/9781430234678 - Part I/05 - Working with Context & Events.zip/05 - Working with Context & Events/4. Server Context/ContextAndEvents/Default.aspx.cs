﻿using System;

namespace ContextAndEvents {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {
           
            switch (Request.Browser.Browser) {
                case "Chrome":
                    Server.Transfer("ChromePage.aspx", true);
                    break;
                case "IE":
                    Server.Transfer("IEPage.aspx", true);
                    break;
                default:
                    Server.Transfer("UnsupportedPage.aspx", true);
                    break;
            }
        }
    }
}