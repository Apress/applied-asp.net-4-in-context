﻿using System;
using System.Web;

namespace ContextAndEvents {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            switch (Request.Browser.Browser) {
                case "Chrome":
                    Context.Items.Add("messageToDisplay", 1);
                    break;
                case "IE":
                    Context.Items.Add("messageToDisplay", 2);
                    break;
            }

            Server.Transfer("SecondPage.aspx");

        }
    }
}