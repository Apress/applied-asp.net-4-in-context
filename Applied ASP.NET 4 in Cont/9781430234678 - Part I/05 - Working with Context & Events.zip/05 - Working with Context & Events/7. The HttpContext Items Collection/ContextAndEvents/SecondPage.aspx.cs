﻿using System;

namespace ContextAndEvents {

    public partial class SecondPage : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            // get the instruction as to which message to display
            // from the HttpContext Items collection
            int messageToDisplay = Context.Items.Contains("messageToDisplay")
                ? (int)Context.Items["messageToDisplay"] : 0;

            if (messageToDisplay == 1) {
                    placeholderH4.InnerText = "This is the first message";
            } else if (messageToDisplay == 2) {
                placeholderH4.InnerText = "This is the second message";
            } else {
                // there was no message instruction
                placeholderH4.InnerText = "No message instruction specified";
            }
        }
    }
}