﻿using System;

namespace ContextAndEvents {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {
           
            switch (Request.Browser.Browser) {
                case "Chrome":
                    Server.Transfer("SecondPage.aspx?messageToDisplay=first", true);
                    break;
                case "IE":
                    Server.Transfer("SecondPage.aspx?messageToDisplay=second", true);
                    break;
                default:
                    Server.Transfer("SecondPage.aspx", true);
                    break;
            }
        }
    }
}