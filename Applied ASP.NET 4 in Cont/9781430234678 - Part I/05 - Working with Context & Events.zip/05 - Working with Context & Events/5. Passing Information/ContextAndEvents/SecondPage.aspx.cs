﻿using System;

namespace ContextAndEvents {

    public partial class SecondPage : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            // get the instruction as to which message to display
            // from the query string
            string messageToDisplay = Request.QueryString["messageToDisplay"];
            if (messageToDisplay != null) {
                if (messageToDisplay == "first") {
                    placeholderH4.InnerText = "This is the first message";
                } else {
                    placeholderH4.InnerText = "This is the second message";
                }
            } else {
                // there was no message instruction
                placeholderH4.InnerText = "No message instruction specified";
            }
        }
    }
}