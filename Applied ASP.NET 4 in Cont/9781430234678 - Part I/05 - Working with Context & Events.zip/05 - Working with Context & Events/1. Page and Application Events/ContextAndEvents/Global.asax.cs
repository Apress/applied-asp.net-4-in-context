﻿using System;

namespace ContextAndEvents {
    public class Global : System.Web.HttpApplication {

        protected void Application_BeginRequest(object sender, EventArgs e) {
            Response.Write(
                string.Format("<p>Request processing started at: {0}<p>", 
                    GetTimeString()));
        }

        protected void Application_EndRequest(object sender, EventArgs e) {
            Response.Write(
                string.Format("<p>Request processing finished at: {0}<p>", 
                    GetTimeString()));
        }

        private string GetTimeString() {
            return DateTime.Now.ToString("hh:mm:ss:ff");                
        }
    }
}