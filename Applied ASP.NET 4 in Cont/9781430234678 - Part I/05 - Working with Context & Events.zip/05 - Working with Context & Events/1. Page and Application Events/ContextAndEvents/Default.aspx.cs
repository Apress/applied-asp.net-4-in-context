﻿using System;

namespace ContextAndEvents {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {
            placeHolderH3.InnerText = "This message was changed in the Page_Load method";
        }

        protected void Page_PreRender(object sender, EventArgs e) {
            placeHolderH3.InnerText 
                = "This message was changed in the Page_PreRender method";
            Response.Write("<h4>This message comes from the Page_PreRender method</h4>");                
        }
    }
}