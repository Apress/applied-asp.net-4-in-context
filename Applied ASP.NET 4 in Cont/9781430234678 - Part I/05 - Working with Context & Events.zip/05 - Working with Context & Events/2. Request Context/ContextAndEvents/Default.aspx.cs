﻿using System;

namespace ContextAndEvents {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            switch (Request.Browser.Browser) {
                case "Chrome":
                    contextDiv.InnerText = "Request made using Google Chrome";
                    break;
                case "IE":
                    contextDiv.InnerText = "Request made using Internet Explorer";
                    break;
                default:
                    contextDiv.InnerText 
                        = string.Format("Request made using other browser: {0}", 
                            Request.Browser.Browser);
                    break;
            }
        }
    }
}