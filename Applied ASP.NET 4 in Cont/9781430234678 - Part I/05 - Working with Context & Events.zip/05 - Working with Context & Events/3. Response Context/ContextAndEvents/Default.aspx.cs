﻿using System;

namespace ContextAndEvents {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            switch (Request.Browser.Browser) {
                case "Chrome":
                    Response.Redirect("ChromePage.aspx", true);
                    break;
                case "IE":
                    Response.Redirect("IEPage.aspx", true);
                    break;
                default:
                    Response.Redirect("UnsupportedPage.aspx", true);
                    break;
            }
        }
    }
}