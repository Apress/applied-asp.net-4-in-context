﻿using System;
using System.Web;

namespace ContextAndEvents {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {
           
            // create an instance of the other class
            MyOtherClass myObject = new MyOtherClass();

            // call a method that relies on context
            myObject.TransferBasedOnBrowser();
        }
    }

    class MyOtherClass {

        public void TransferBasedOnBrowser() {
            // get the HttpContext object
            HttpContext myContext = HttpContext.Current;
   
            // switch on the browser type
            switch (myContext.Request.Browser.Browser) {
                case "Chrome":
                    myContext.Server
                        .Transfer("SecondPage.aspx?messageToDisplay=first", true);
                    break;
                case "IE":
                    myContext.Server
                        .Transfer("SecondPage.aspx?messageToDisplay=second", true);
                    break;
                default:
                    myContext.Server
                        .Transfer("SecondPage.aspx", true);
                    break;
            }
        }
    }
}