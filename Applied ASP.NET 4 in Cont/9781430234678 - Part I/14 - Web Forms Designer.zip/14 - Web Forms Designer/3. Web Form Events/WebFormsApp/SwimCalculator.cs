﻿using System;

namespace WebFormsApp {

public struct SwimCalcResult {
    public float Distance;
    public float Calories;
    public float Pace;
}

public class SwimCalc {
    private const float metersToMiles = 0.00062137119223733f;
    private const float minsPerHour = 60f;

    public static SwimCalcResult PerformCalculation(int lapsParam, int lengthParam,
        int minsParam, int calsPerHourParam) {

        // validate the parameter values - we need all values to be greater than zero
        foreach (int paramValue in new[] {lapsParam, lengthParam, 
            minsParam, calsPerHourParam}) {

            if (paramValue < 1) {
                // this is not a value we can work with
                throw new ArgumentOutOfRangeException();
            }
        }
            
        // create the result
        SwimCalcResult result = new SwimCalcResult();

        result.Distance = (lapsParam * lengthParam) * metersToMiles;
        result.Calories = (minsParam / minsPerHour) * calsPerHourParam;
        result.Pace = (minsParam * minsPerHour) / lapsParam;

        // return the result
        return result;
    }
}
}
