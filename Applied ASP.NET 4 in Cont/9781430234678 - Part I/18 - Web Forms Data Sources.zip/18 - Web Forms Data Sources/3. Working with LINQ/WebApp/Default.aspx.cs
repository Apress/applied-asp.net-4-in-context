﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace WebApp {

    public partial class Default : System.Web.UI.Page {
        
        protected void Page_Load(object src, EventArgs e) {

            //var results = new TrainingDataEntities().Events
            //            .Select(ev => ev.Athlete)
            //            .Distinct();


            string xmlDataString = @"<Athletes>
                                        <Athlete>
                                            <Name>Adam Freeman</Name>
                                            <City>London</City>
                                        </Athlete>
                                        <Athlete>
                                            <Name>Joe Smith</Name>
                                            <City>New York</City>
                                        </Athlete>
                                    </Athletes>";


            if (!IsPostBack) {

                var results = XDocument.Parse(xmlDataString)
                    .Descendants("Name")
                    .Select(elem => elem.Value);

                DropDownList1.DataSource = results;
                DropDownList1.DataBind();
            }
        }
    }
}