﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp {
    public partial class Test : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {


            var results = new TrainingDataEntities().Events
              .Select(ev => ev.Athlete)
              .Distinct();
            DropDownList1.DataSource = results;
            DropDownList1.DataBind();

            var eventResults = new TrainingDataEntities().Events
                .Where(ev => ev.Athlete == DropDownList1.SelectedValue)
                .Select(ev => new {
                    Date = ev.Date,
                    Type = ev.Type,
                    Time = ev.OverallTime
                });
            ListView1.DataSource = eventResults;
            ListView1.DataBind();

        }
    }
}