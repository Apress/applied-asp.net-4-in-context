﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace WebApp {

    public partial class Default : System.Web.UI.Page {
        public IEnumerable<Event> FilteredEvents = new TrainingDataEntities().Events.Where(e => e.Athlete == "Adam Freeman");



        protected void Page_Load(object sender, EventArgs e) {

        }
    }



}