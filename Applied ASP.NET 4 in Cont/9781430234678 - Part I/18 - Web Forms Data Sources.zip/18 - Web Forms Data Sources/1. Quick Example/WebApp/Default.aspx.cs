﻿using System;

namespace WebApp {

    public class Fruit {
        public string Name { get; set; }
        public string Color { get; set; }
    }

    public partial class Default : System.Web.UI.Page {
        public Fruit[] FruitDataArray = new[] {
            new Fruit() {Name = "Apple", Color = "Green"},
            new Fruit() {Name = "Banana", Color = "Yellow"},
            new Fruit() {Name = "Cherry", Color = "Red"},
            new Fruit() {Name = "Plum", Color = "Red"}
        };

        protected void Page_Load(object sender, EventArgs e) {

        }
    }



}