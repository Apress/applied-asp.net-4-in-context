﻿(function ($) {
    prettyTable = function () {
        $('a').button().css('color', '#ffffff');
        $('td a').css('font-size', 'smaller');

        $('tr:has(td)').hover(
            function () {
                $(this).find('td')
                    .css({ 'background-color': '#007F7F',
                        'color': '#ffffff'
                    });
            },
            function () {
                $(this).find('td')
                    .css({ 'background-color': '',
                        'color': ''
                    });
            }
        ).click(function () {
            document.location =  $(this).find('a:contains("Edit")').attr('href');
        });
    }
})(jQuery);