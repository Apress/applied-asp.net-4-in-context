﻿using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;

namespace TriathlonTraining {

    [ServiceContract]
    [AspNetCompatibilityRequirements(RequirementsMode
        = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(IncludeExceptionDetailInFaults = true)] 
    public class TriathlonService {

        [OperationContract]
        [WebGet]
        public IEnumerable<EventItem> GetEventData(string type) {

            List<EventItem> results = new List<EventItem>();

            using (TrainingDataEntities context = new TrainingDataEntities()) {

                IEnumerable<Event> events = (type == null || type == "All") 
                    ? DataAccess.GetAllEvents(context) : DataAccess.GetEventsByType(context, type);

                foreach (Event e in events) {
                    results.Add(new EventItem() {
                        Key = e.ID,
                        Date = e.Date.ToString("MM/dd"),
                        Athlete = e.Athlete,
                        EventType = e.Type,
                        SwimTime = e.SwimTime.ToString(),
                        CycleTime = e.CycleTime.ToString(),
                        RunTime = e.RunTime.ToString(),
                        OverallTime = e.OverallTime.ToString(),
                        Rank = DataAccess.GetPersonalRanking(context, e).OverallRank,
                        ReferenceRank = DataAccess.GetReferenceRanking(context, e).OverallRank
                    });
                }
            }
            return results;
        }

        [OperationContract]
        [WebGet]
        public PerformanceReport GetPerformanceData(string athlete) {

            using (TrainingDataEntities context = new TrainingDataEntities()) {

                System.Threading.Thread.Sleep(2000);

                // get the times
                Event sprintTimes 
                    = DataAccess.GetBestTimes(context, athlete, "Sprint");
                Event olympicTimes 
                    = DataAccess.GetBestTimes(context, athlete, "Olympic");
                // get the rankings
                RankingSet sprintRanks 
                    = DataAccess.GetReferenceRanking(context, sprintTimes);
                RankingSet olympicRanks 
                    = DataAccess.GetReferenceRanking(context, olympicTimes);

                // create populate and return the result
                return new PerformanceReport() {

                    sprintSwimTime = sprintTimes.SwimTime.ToString(),
                    sprintCycleTime = sprintTimes.CycleTime.ToString(),
                    sprintRunTime = sprintTimes.RunTime.ToString(),
                    sprintOverallTime = sprintTimes.OverallTime.ToString(),
                    olympicSwimTime = olympicTimes.SwimTime.ToString(),
                    olympicCycleTime = olympicTimes.CycleTime.ToString(),
                    olympicRunTime = olympicTimes.RunTime.ToString(),
                    olympicOverallTime = olympicTimes.OverallTime.ToString(),

                    sprintSwimRank = sprintRanks.SwimRank,
                    sprintCycleRank = sprintRanks.CycleRank,
                    sprintRunRank = sprintRanks.RunRank,
                    sprintOverallRank = sprintRanks.OverallRank,
                    olympicSwimRank = olympicRanks.SwimRank,
                    olympicCycleRank = olympicRanks.CycleRank,
                    olympicRunRank = olympicRanks.RunRank,
                    olympicOverallRank = olympicRanks.OverallRank
                };
            }
        }
    }

    public class EventItem {
        public int Key;
        public string Date;
        public string Athlete;
        public string EventType;
        public string SwimTime, CycleTime, RunTime, OverallTime;
        public int Rank, ReferenceRank;
    }

    public class PerformanceReport {
        // times
        public string sprintSwimTime, olympicSwimTime;
        public string sprintCycleTime, olympicCycleTime;
        public string sprintRunTime, olympicRunTime;
        public string sprintOverallTime, olympicOverallTime;
        // ranks
        public int sprintSwimRank, olympicSwimRank;
        public int sprintCycleRank, olympicCycleRank;
        public int sprintRunRank, olympicRunRank;
        public int sprintOverallRank, olympicOverallRank;
    }
}
