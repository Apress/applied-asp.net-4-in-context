﻿using System;
using System.Web.UI.WebControls;

namespace WebApp {
    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            //string[] textValues = {"First Item", "Second Item", 
            //                          "Third Item", "Fourth Item"};

            //foreach (string str in textValues) {
            //    BulletedList1.Items.Add(new ListItem(str));
            //}
        }
    }
}