﻿using System;

namespace WebApp {
    public partial class Default : System.Web.UI.Page {

    }
}