﻿using System;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp {
    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            Button myDivButton = new Button();
            myDivButton.Text = "Press Me!";
            myDivButton.Click += new EventHandler(myDivButton_Click);

            myDiv.Controls.Add(myDivButton);
            myDiv.Attributes.CssStyle.Add(HtmlTextWriterStyle.BackgroundColor, "Bisque");

            // repeat the process using a Panel control

            Button myPanelButton = new Button();
            myPanelButton.Text = "Press Me!";
            myPanelButton.Click += new EventHandler(myPanelButton_Click);

            myPanel.Controls.Add(myPanelButton);
            myPanel.BackColor = Color.Bisque;

        }

        void myPanelButton_Click(object sender, EventArgs e) {
            results.InnerText = "The panel button was pressed";
        }

        void myDivButton_Click(object sender, EventArgs e) {
            results.InnerText = "The div button was pressed";
        }
    }
}