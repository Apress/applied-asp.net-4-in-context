﻿using System;
using System.Web.UI.WebControls;

namespace WebApp {
    public partial class Default : System.Web.UI.Page {

        public void Page_Load() {

          //  results.InnerText = DateTime.Now.ToString();    

            //Button myButton = new Button();
            //myButton.Text = "Press Me!";

            //PlaceHolder1.Controls.Add(myButton);

        }

        protected void TreeView1_SelectedNodeChanged(object sender, EventArgs e) {
            results.InnerText = "Selected Node Changed " + DateTime.Now.ToString();
        }

        protected void TreeView1_TreeNodeCheckChanged(object sender, TreeNodeEventArgs e) {
            results.InnerText = "Node Checked Changed " + DateTime.Now.ToString();
        }

        protected void TreeView1_TreeNodeCollapsed(object sender, TreeNodeEventArgs e) {
            results.InnerText = "Node Collapsed " + DateTime.Now.ToString();
        }

        protected void TreeView1_TreeNodeExpanded(object sender, TreeNodeEventArgs e) {
            results.InnerText = "Node Expanded " + DateTime.Now.ToString();
        }

        protected void Button1_Click(object sender, EventArgs e) {
            MultiView1.ActiveViewIndex = (MultiView1.ActiveViewIndex + 1) % 3;
        }
    }
}