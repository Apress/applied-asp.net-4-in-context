﻿using System;
using System.Web.UI.HtmlControls;

namespace DataApp {

    public partial class ListEvents : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            // create the entity data model context object
            using (TrainingDataEntities context = new TrainingDataEntities()) {

                // enumerate the objects in the context.Events property - these
                // correspond to the rows in the Events table in the database
                foreach (Event ev in context.Events) {
                    // process the entity object
                    ProcessEvent(ev);
                }
            }
        }

        private void ProcessEvent(Event eventParam) {

            // create a new table row
            HtmlTableRow row = new HtmlTableRow();

            row.Cells.Add(CreateTableCell(eventParam.Date.ToString("MM/dd")));
            row.Cells.Add(CreateTableCell(eventParam.Athlete));
            row.Cells.Add(CreateTableCell(eventParam.Type));
            row.Cells.Add(CreateTableCell(eventParam.SwimTime.ToString()));
            row.Cells.Add(CreateTableCell(eventParam.CycleTime.ToString()));
            row.Cells.Add(CreateTableCell(eventParam.RunTime.ToString()));
            row.Cells.Add(CreateTableCell(eventParam.OverallTime.ToString()));

            // add the row to the table
            resultsTable.Rows.Add(row);
        }

        private HtmlTableCell CreateTableCell(string textParam) {
            return new HtmlTableCell() { InnerText = textParam };
        }
    }
}