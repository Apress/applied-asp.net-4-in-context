﻿using System;
using System.Globalization;

namespace DataApp {

    public partial class AddEvent : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            using (TrainingDataEntities context = new TrainingDataEntities()) {

                // do the setup - placed in a seperate method for clarity
                if (ViewState["setupComplete"] == null) {
                    PerformPageSetup(context);
                    ViewState["setupComplete"] = true;
                }

                if (IsPostBack) {
                    try {

                        // get the elements of the date
                        int day = int.Parse(dayText.Value);
                        int month = monthSelect.SelectedIndex + 1;
                        int year = int.Parse(yearText.Value);

                        // add a new event to the database
                        DataAccess.AddEvent(context, 
                            new DateTime(year, month, day),
                            athleteSelect.Value,
                            eventTypeSelect.Value,
                            TimeSpan.Parse(swimText.Value),
                            TimeSpan.Parse(cycleText.Value),
                            TimeSpan.Parse(runText.Value)
                            );

                        // transfer the user to the list page
                        Response.Redirect("ListEvents.aspx");

                    } catch (FormatException) {
                        // set the error text
                        errorDiv.InnerText = "Cannot parse inputs";
                    }
                }
            }
        }

        private void PerformPageSetup(TrainingDataEntities context) {

            // get the current culture info
            DateTimeFormatInfo formatInfo = CultureInfo.CurrentCulture.DateTimeFormat;

            // populate the month select element
            monthSelect.Items.Clear();
            for (int i = 1; i < 13; i++) {
                monthSelect.Items.Add(formatInfo.GetAbbreviatedMonthName(i));
            }

            // get the current date anduse it to select a month and set the day and year
            DateTime now = DateTime.Now;
            monthSelect.SelectedIndex = now.Month - 1;
            dayText.Value = now.Day.ToString();
            yearText.Value = now.Year.ToString();

            // populate the athletes names
            athleteSelect.Items.Clear();
            foreach (string name in DataAccess.GetAthleteNames(context)) {
                athleteSelect.Items.Add(name);
            }

            // populate the event types
            eventTypeSelect.Items.Clear();
            foreach (string name in DataAccess.GetEventTypeNames(context)) {
                eventTypeSelect.Items.Add(name);
            }
        }
    }
}