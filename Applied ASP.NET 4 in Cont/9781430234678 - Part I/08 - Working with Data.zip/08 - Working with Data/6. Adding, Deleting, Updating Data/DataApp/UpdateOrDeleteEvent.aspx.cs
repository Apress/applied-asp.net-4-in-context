﻿using System;
using System.Globalization;
using System.Web.UI.HtmlControls;

namespace DataApp {

    public partial class UpdateEvent : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            using (TrainingDataEntities context = new TrainingDataEntities()) {

                // do the setup - placed in a seperate method for clarity
                if (ViewState["setupComplete"] == null) {
                    PerformPageSetup(context);
                    ViewState["setupComplete"] = true;
                }

                if (!IsPostBack) {
                    
                    // make sure we have query string values for the key and 
                    // the mode and can obtain the correspnding Event object
                    // if not, then push the user back towards the list page
                    string mode; 
                    int eventID;
                    Event targetEvent;

                    if ((mode = Request.QueryString["mode"]) != null
                        && int.TryParse(Request.QueryString["id"], out eventID)
                        && (targetEvent = DataAccess.GetEventByID(context, 
                            eventID)) != null) {

                        // set the hidden fields in the form
                        this.modeInput.Value = mode;
                        this.keyInput.Value = eventID.ToString();

                        // use the property values of the event to populate the page contols
                        monthSelect.SelectedIndex = targetEvent.Date.Month - 1;
                        dayText.Value = targetEvent.Date.Day.ToString();
                        yearText.Value = targetEvent.Date.Year.ToString();

                        // set the selected index for the the athlete and event controls
                        SetSelectIndex(athleteSelect, targetEvent.Athlete);
                        SetSelectIndex(eventTypeSelect, targetEvent.Type);

                        // set the times
                        swimText.Value = targetEvent.SwimTime.ToString();
                        cycleText.Value = targetEvent.CycleTime.ToString();
                        runText.Value = targetEvent.RunTime.ToString();

                        // if we are in delete mode, then disable the HTML controls
                        if (mode == "delete") {
                            monthSelect.Disabled = true;
                            dayText.Disabled = true;
                            yearText.Disabled = true;
                            athleteSelect.Disabled = true;
                            eventTypeSelect.Disabled = true;
                            swimText.Disabled = true;
                            cycleText.Disabled = true;
                            runText.Disabled = true;
                        }

                        // set the button text based on the mode
                        button.Value = mode == "edit" ? "Save" : "Delete";

                    } else {
                        // we have a problem - just send the user back to the list
                        Response.Redirect("/ListEvents.aspx");
                    }
                    
                } else {
                    if (modeInput.Value == "edit") {
                        // this is an edit request that requires an update
                        DataAccess.UpdateEvent(context, int.Parse(keyInput.Value),
                            new DateTime(
                                int.Parse(yearText.Value),
                                monthSelect.SelectedIndex + 1,
                                int.Parse(dayText.Value)),
                            athleteSelect.Value,
                            eventTypeSelect.Value,
                            TimeSpan.Parse(swimText.Value),
                            TimeSpan.Parse(cycleText.Value),
                            TimeSpan.Parse(runText.Value));

                    } else {
                        // this is a delete request
                        DataAccess.DeleteEventByID(context, int.Parse(keyInput.Value));
                    }

                    // return the user to the list
                    Response.Redirect("ListEvents.aspx");
                }
            }
        }

        private void SetSelectIndex(HtmlSelect selectParam, string targetValue) {
            for (int i = 0; i < selectParam.Items.Count; i++) {
                if (selectParam.Items[i].Text == targetValue) {
                    selectParam.SelectedIndex = i;
                    break;
                }
            }
        }

        private void PerformPageSetup(TrainingDataEntities context) {

            // get the current culture info
            DateTimeFormatInfo formatInfo = CultureInfo.CurrentCulture.DateTimeFormat;

            // populate the month select element
            monthSelect.Items.Clear();
            for (int i = 1; i < 13; i++) {
                monthSelect.Items.Add(formatInfo.GetAbbreviatedMonthName(i));
            }

            // get the current date anduse it to select a month and set the day and year
            DateTime now = DateTime.Now;
            monthSelect.SelectedIndex = now.Month - 1;
            dayText.Value = now.Day.ToString();
            yearText.Value = now.Year.ToString();

            // populate the athletes names
            athleteSelect.Items.Clear();
            foreach (string name in DataAccess.GetAthleteNames(context)) {
                athleteSelect.Items.Add(name);
            }

            // populate the event types
            eventTypeSelect.Items.Clear();
            foreach (string name in DataAccess.GetEventTypeNames(context)) {
                eventTypeSelect.Items.Add(name);
            }
        }
    }
}