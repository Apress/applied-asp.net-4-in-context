﻿using System;
using System.Collections.Generic;
using System.Web.UI.HtmlControls;

namespace DataApp {

    public partial class ListEvents : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            // create the entity data model context object
            using (TrainingDataEntities context = new TrainingDataEntities()) {

                // populate the select control if needed
                if (ViewState["setupComplete"] == null) {
                    foreach (string name in DataAccess.GetEventTypeNames(context)) {
                        eventSelector.Items.Add(name);
                    }
                    ViewState["setupComplete"] = true;
               }

                // define the collection of events that we will process
                IEnumerable<Event> eventsToProcess;

                if (IsPostBack && eventSelector.Value != "All") {

                    // get the events filtered by event type
                    eventsToProcess = DataAccess.GetEventsByType(context, eventSelector.Value);

                } else {
                    // get all of the events
                    eventsToProcess = DataAccess.GetAllEvents(context);
                }

                // process the selected events
                foreach (Event ev in eventsToProcess) {

                    // get the personal ranking information
                    int personalRank  = DataAccess.GetPersonalRanking(context, ev).OverallRank;
                        
                    // get the reference rank information
                    int referenceRank = DataAccess.GetReferenceRanking(context, ev).OverallRank;
                        
                    // process the entity object
                    ProcessEvent(ev, personalRank, referenceRank);
                }
            }
        }

        private void ProcessEvent(Event eventParam, int personalRankParam,
            int referenceRankParam) {

            // create a new table row
            HtmlTableRow row = new HtmlTableRow();

            row.Cells.Add(CreateTableCell(eventParam.Date.ToString("MM/dd")));
            row.Cells.Add(CreateTableCell(eventParam.Athlete));
            row.Cells.Add(CreateTableCell(eventParam.Type));
            row.Cells.Add(CreateTableCell(eventParam.SwimTime.ToString()));
            row.Cells.Add(CreateTableCell(eventParam.CycleTime.ToString()));
            row.Cells.Add(CreateTableCell(eventParam.RunTime.ToString()));
            row.Cells.Add(CreateTableCell(eventParam.OverallTime.ToString()));

            // add the ranking information
            row.Cells.Add(CreateTableCell(personalRankParam.ToString()));
            row.Cells.Add(CreateTableCell(referenceRankParam.ToString()));

            // add the action links
            row.Cells.Add(CreateLinkTableCell("/UpdateOrDeleteEvent.aspx", "Edit", eventParam.ID, "edit"));
            row.Cells.Add(CreateLinkTableCell("/UpdateOrDeleteEvent.aspx", "Delete", eventParam.ID, "delete"));

            // add the row to the table
            resultsTable.Rows.Add(row);
        }

        private HtmlTableCell CreateTableCell(string textParam) {
            return new HtmlTableCell() { InnerText = textParam };
        }

        private HtmlTableCell CreateLinkTableCell(string urlParam, string textParam, int idParam, string modeParam) {
            // create the anchor
            HtmlAnchor anchor = new HtmlAnchor() {
                HRef = string.Format("{0}?id={1}&mode={2}", urlParam, idParam, modeParam),
                InnerText = textParam};
            // add the anchor to a new cell
            HtmlTableCell cell = new HtmlTableCell();
            cell.Controls.Add(anchor);
            // return the cell
            return cell;
        }
    }
}