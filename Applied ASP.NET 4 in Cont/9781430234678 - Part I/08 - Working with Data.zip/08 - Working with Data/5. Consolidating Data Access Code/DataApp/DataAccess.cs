﻿using System.Collections.Generic;
using System.Linq;

namespace DataApp {

    public static class DataAccess {

        ///////////////////////////////
        // EventType related methods //
        //////////////////////////////

        public static string[] GetEventTypeNames(TrainingDataEntities contextParam) {
            return contextParam.EventTypes.Select(e => e.Name).ToArray();
        }

        /////////////////////////////
        // Athlete related methods //
        /////////////////////////////

        public static string[] GetAthleteNames(TrainingDataEntities contextParam) {
            return contextParam.Athletes.Select(e => e.Name).ToArray();
        }

        /////////////////////////////
        // Ranking related methods //
        /////////////////////////////

        public static RankingSet GetReferenceRanking(TrainingDataEntities contextParam,
            Event eventParam) {

            return new RankingSet(contextParam.GetReferenceRanking(eventParam.Type,
                eventParam.SwimTime, eventParam.CycleTime,
                eventParam.RunTime, eventParam.OverallTime));
        }

        public static RankingSet GetPersonalRanking(TrainingDataEntities contextParam,
            Event eventParam) {

            return new RankingSet(contextParam.GetPersonalRanking(eventParam.Athlete,
                eventParam.Type, eventParam.SwimTime, eventParam.CycleTime,
                eventParam.RunTime, eventParam.OverallTime));
        }

        ///////////////////////////
        // Event related methods //
        ///////////////////////////

        public static IEnumerable<Event> GetAllEvents(TrainingDataEntities contextParam) {
            return contextParam.Events;
        }

        public static IEnumerable<Event> GetEventsByType(TrainingDataEntities contextParam,
            string typeParam) {

            return contextParam.Events.Where(e => e.Type == typeParam).Select(e => e);
        }
    }
}