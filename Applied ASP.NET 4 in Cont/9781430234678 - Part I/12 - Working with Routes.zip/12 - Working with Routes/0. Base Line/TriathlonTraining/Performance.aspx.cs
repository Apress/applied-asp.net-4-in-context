﻿using System;

namespace TriathlonTraining {

    public partial class Performance : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {
            using (TrainingDataEntities context = new TrainingDataEntities()) {

                athleteSelector.Items.Clear();
                foreach (string name in DataAccess.GetAthleteNames(context)) {
                    athleteSelector.Items.Add(name);
                }
            }
        }
    }
}