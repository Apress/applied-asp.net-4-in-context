﻿using System;
using System.Collections.Generic;
using System.Web.UI.HtmlControls;

namespace TriathlonTraining {
    public partial class ListEvents : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

            // create the entity data model context object
            using (TrainingDataEntities context = new TrainingDataEntities()) {

                // populate the select control if needed
                if (ViewState["setupComplete"] == null) {
                    foreach (string name in DataAccess.GetEventTypeNames(context)) {
                        eventSelector.Items.Add(name);
                    }
                    ViewState["setupComplete"] = true;
                }
            }
        }
    }
}