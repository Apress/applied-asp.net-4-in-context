﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization.Json;

namespace TriathlonTraining {
    public partial class Calculator : System.Web.UI.Page {

        private const float metersToMiles = 0.00062137119223733f;
        private const float minsPerHour = 60f;

        protected void Page_Load(object sender, EventArgs e) {

            if (IsPostBack || RouteData.Values.Count > 0) {

                if (RouteData.Values.Count > 0) {
                    // we know that we have at least two values to process
                    lapsInput.Value = RouteData.Values["firstVal"].ToString();
                    lengthInput.Value = RouteData.Values["secondVal"].ToString();
                    // see if we have a variable length item
                    if (RouteData.Values["otherVals"] != null) {
                        string[] additionalValues = RouteData.Values["otherVals"].ToString().Split('/');
                        minsInput.Value = additionalValues[0];
                        if (additionalValues.Length > 1) {
                            calsInput.Value = additionalValues[1];
                        }
                    }
                }

                // set the visibilty of the results div
                resultsDiv.Style.Add("display", "block");

                // parse the input values
                int laps = int.Parse(lapsInput.Value);
                int length = int.Parse(lengthInput.Value);
                int minutes = int.Parse(minsInput.Value);
                int calories = int.Parse(calsInput.Value);

                // perform the calculation and set the result values
                string distanceResultString
                    = ((laps * length) * metersToMiles).ToString("F2");
                string caloriesResultString
                    = ((minutes / minsPerHour) * calories).ToString("F0");
                string paceResultString
                    = ((minutes * minsPerHour) / laps).ToString("F0");

                if (Request.Form["resultFormat"] == "JSON") {

                    JSONCalculationResult calcResult = new JSONCalculationResult() {
                        distance = distanceResultString,
                        calories = caloriesResultString,
                        pace = paceResultString
                    };

                    DataContractJsonSerializer serializer = new DataContractJsonSerializer(calcResult.GetType());
                    serializer.WriteObject(Response.OutputStream, calcResult);

                    Response.ContentType = "application/JSON";
                    Response.End();
                } else {
                    distanceResult.InnerText = distanceResultString;
                    caloriesResult.InnerText = caloriesResultString;
                    paceResult.InnerText = paceResultString;
                    sourceResult.InnerText = "Non-AJAX";
                }   
            }
        }
    }

    [Serializable]
    public class JSONCalculationResult {
        public string distance;
        public string calories;
        public string pace;
    }
}