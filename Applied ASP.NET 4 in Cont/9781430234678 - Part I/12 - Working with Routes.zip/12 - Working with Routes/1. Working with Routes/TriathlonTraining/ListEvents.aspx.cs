﻿using System;

namespace TriathlonTraining {
    public partial class ListEvents : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

            // create the entity data model context object
            using (TrainingDataEntities context = new TrainingDataEntities()) {

                // populate the select control if needed
                if (ViewState["setupComplete"] == null) {
                    foreach (string name in DataAccess.GetEventTypeNames(context)) {
                        eventSelector.Items.Add(name);
                    }
                    ViewState["setupComplete"] = true;
                }

                // get the value of the route data variable
                object specifiedSport = RouteData.Values["eventType"];
                if (specifiedSport != null) {

                    // get the list item that contains the selected event type
                    eventSelector.Items
                        .FindByText(specifiedSport.ToString()).Selected = true;
                }
            }
        }
    }
}