﻿using System;
using System.Web.Routing;
using System.Text;

namespace TriathlonTraining {
    public class Global : System.Web.HttpApplication {

        protected void Application_Start(object sender, EventArgs e) {

            RegisterRoutes(RouteTable.Routes);
        }

public static void RegisterRoutes(RouteCollection routes) {

    routes.MapPageRoute("", "Events", "~/ListEvents.aspx");
    routes.MapPageRoute("", "Performance", "~/Performance.aspx");
    routes.MapPageRoute("", "Calculator", "~/Calculator.aspx");

    routes.MapPageRoute("calcRoute", "Calculator", "~/Calculator.aspx");

    routes.MapPageRoute("variableCalcRoute",
        "Calculator/{firstVal}/{secondVal}/{*otherVals}",
        "~/Calculator.aspx");

    routes.MapPageRoute("addRoute", "Events/Add", "~/AddEvent.aspx");

    routes.MapPageRoute("editOrDelete",
        "Events/{mode}/{id}",
        "~/UpdateOrDeleteEvent.aspx",
        true,
        new RouteValueDictionary() {{"id", "1"}},
        new RouteValueDictionary() { { "mode", "Edit|Delete"}});

    using (TrainingDataEntities context = new TrainingDataEntities()) {
        string[] eventTypes = DataAccess.GetEventTypeNames(context);
        StringBuilder builder = new StringBuilder("All");
        for (int i = 0; i < eventTypes.Length; i++) {
            builder.Append('|').Append(eventTypes[i]);
        }

        routes.MapPageRoute("default", "Events/{eventType}",
            "~/ListEvents.aspx",
            true,
            new RouteValueDictionary() { { "eventType", "All" } },
            new RouteValueDictionary() { { "eventType", builder.ToString() } }
        );
    }

    routes.MapPageRoute("", "Events/{placeholder}",
        "~/ListEvents.aspx",
        true,
        new RouteValueDictionary() { { "eventType", "All" } });
}

    }
}