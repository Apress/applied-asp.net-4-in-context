﻿using System;
using System.Web.Routing;
using System.Web;

namespace TriathlonTraining {
    public partial class Site : System.Web.UI.MasterPage {

        protected void Page_Load(object sender, EventArgs e) {

            DataBind();

            using (TrainingDataEntities context = new TrainingDataEntities()) {
                // get the total data from the database
                DataTotals totals = DataAccess.GetDataTotals(context);
                // use the totals to update the span contents for the footer
                eventCountSpan.InnerText = totals.EventTotal.ToString();
                mileCountSpan.InnerText = string.Format("{0:F1}", totals.MileTotal);
                hourCountSpan.InnerText = string.Format("{0} Hours and {1} Minutes",
                    totals.TimeTotal.Hours, totals.TimeTotal.Minutes);
            }
        }

        protected string GetRealPageName() {
            RouteData routes 
                = RouteTable.Routes.GetRouteData(new HttpContextWrapper(this.Context));
            if (routes != null && routes.RouteHandler is PageRouteHandler) {
                PageRouteHandler handler = (PageRouteHandler)routes.RouteHandler;
                int charIndex = handler.VirtualPath.IndexOf('/');
                return handler.VirtualPath.Substring(charIndex);
            } else {
                return Request.Path;
            }
        }
    }
}