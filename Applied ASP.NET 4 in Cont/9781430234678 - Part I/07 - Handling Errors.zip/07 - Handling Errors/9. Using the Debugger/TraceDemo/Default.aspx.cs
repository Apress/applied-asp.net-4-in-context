﻿using System;
using System.Diagnostics;

namespace TraceDemo {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            // define a variable for the running total
            float total = 0;

            // get the running total from the session if possible
            if (Session["runningTotal"] != null) {
                total = (float)Session["runningTotal"];
            }

            if (IsPostBack && Session["runningTotal"] == null) {
                Debugger.Break();
            }

            if (IsPostBack) {
                // this is a form post - get the value from the HTML control
                string data = numericValue.Value;
                // try to parse the data toa numeric value
                if (data != null) {
                    float incrementalValue = 0;
                    if (float.TryParse(data, out incrementalValue)) {
                        total += incrementalValue;
                    }
                }
            }

            // update the running total on the HTML control
            runningTotal.InnerText = string.Format("{0:F2}", total);

            // update the value stored in the session
            Session["runningTotals"] = total;
        }
    }
}