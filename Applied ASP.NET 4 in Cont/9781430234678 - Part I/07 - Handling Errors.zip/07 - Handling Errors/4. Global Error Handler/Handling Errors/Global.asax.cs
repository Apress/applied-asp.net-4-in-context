﻿using System;
using System.Web;

namespace Handling_Errors {
    public class Global : System.Web.HttpApplication {

        protected void Application_Error(object sender, EventArgs e) {
            // get the exception that has caused the Error event to be invoked
            Exception ex = Server.GetLastError();

            // convert the exception so that we have an HttpUnhandledException
            HttpUnhandledException unhandledEx = ex as HttpUnhandledException;

            // check the type of the inner exception - we only want to deal with one type
            if (unhandledEx != null && unhandledEx.InnerException is InvalidOperationException) {
                // show the custom error page
                Server.Transfer("/CustomError.aspx");
            }
        }
    }
}