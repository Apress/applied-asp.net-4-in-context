﻿using System;
using System.Web.UI;

namespace Handling_Errors {

    public class PageController : Page {

        protected virtual void Page_Error(object sender, EventArgs e) {
            // get the exception that has caused the Error event to be invoked
            Exception ex = Server.GetLastError();

            // check the type of the exception - we only want to deal with 
            // the ArgumentOutOfRangeException in this class
            if (ex is ArgumentOutOfRangeException) {
                // show the custom error page
                Server.Transfer("/CustomError.aspx");
            }
        }
    }
}