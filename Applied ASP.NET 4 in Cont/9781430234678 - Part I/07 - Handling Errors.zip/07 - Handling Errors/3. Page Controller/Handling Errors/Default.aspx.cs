﻿using System;

namespace Handling_Errors {

    public partial class Default : PageController {

        protected void Page_Load(object sender, EventArgs e) {

            if (IsPostBack) {
                if (this.ArgumentOutOfRangeExceptionControl.Checked) {
                    throw new ArgumentOutOfRangeException();
                } else if (this.InvalidOperationExceptionControl.Checked) {
                    throw new InvalidOperationException();
                } else if (this.NotImplementedExceptionControl.Checked) {
                    throw new NotImplementedException();
                } 
            }
        }
    }
}