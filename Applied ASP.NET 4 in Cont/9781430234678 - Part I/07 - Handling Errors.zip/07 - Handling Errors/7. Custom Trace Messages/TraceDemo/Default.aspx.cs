﻿using System;

namespace TraceDemo {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {
            Trace.Write("---Started");

            // define a variable for the running total
            Trace.Write("Initializing local variable");
            float total = 0;

            // get the running total from the session if possible
            if (Session["runningTotal"] != null) {
                Trace.Write("Session state data obtained");
                total = (float)Session["runningTotal"];
            } else if (IsPostBack) {
                Trace.Warn("No session state data found");
            } else {
                Trace.Write("No session data for initial request");
            }

            if (IsPostBack) {
                // this is a form post - get the value from the HTML control
                string data = numericValue.Value;
                Trace.Write(string.Format("User has entered data: {0}", data));
                // try to parse the data toa numeric value
                if (data != null) {
                    float incrementalValue = 0;
                    if (float.TryParse(data, out incrementalValue)) {
                        total += incrementalValue;
                        Trace.Write(string.Format("Numeric value: {0}, new total: {1}", 
                            incrementalValue, total));
                    } else {
                        Trace.Warn("Cannot parse data to float value");
                    }
                } else {
                    Trace.Warn("No data has been provided by user");
                }
            }

            // update the running total on the HTML control
            Trace.Write("Setting display for total");
            runningTotal.InnerText = string.Format("{0:F2}", total);

            // update the value stored in the session
            Trace.Write("Setting new state data value");
            Session["runningTotals"] = total;
            Trace.Write("---Finished");
        }
    }
}