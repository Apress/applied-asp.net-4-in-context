﻿using System;

namespace Handling_Errors {
    public partial class CustomError : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            // get the exception that we are dealing with
            Exception ex = Server.GetLastError();

            // check that we have an exception - if we don't
            // then transfer the user to the main page
            if (ex != null) {

                // set the content of the HTML controls based on the exception
                exceptionType.InnerHtml = string.Format("<h3>Error page: {0}</h3>", ex.GetType().ToString());
                message.InnerHtml = "<p>A useful description for the user</p>";

                // clear the error
                Server.ClearError();

            } else {
                Server.Transfer("/Default.aspx");
            }
        }
    }
}