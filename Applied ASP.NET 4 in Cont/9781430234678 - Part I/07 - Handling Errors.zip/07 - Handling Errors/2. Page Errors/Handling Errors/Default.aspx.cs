﻿using System;

namespace Handling_Errors {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            if (IsPostBack) {
                if (this.ArgumentOutOfRangeExceptionControl.Checked) {
                    throw new ArgumentOutOfRangeException();
                } else if (this.InvalidOperationExceptionControl.Checked) {
                    throw new InvalidOperationException();
                } else if (this.NotImplementedExceptionControl.Checked) {
                    throw new NotImplementedException();
                } 
            }
        }

        protected void Page_Error(object sender, EventArgs e) {

            // get the exception that has caused the Error event to be invoked
            Exception ex = Server.GetLastError();

            // check the type of the exception - we only want to deal with 
            // the ArgumentOutOfRangeException in this class
            if (ex is ArgumentOutOfRangeException) {
                // show the custom error page
                Server.Transfer("/CustomError.aspx");
            }
        }
    }
}