﻿using System;
using System.Text;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace SimplePages {

    public partial class Default : Page {

        protected void Page_Load(object sender, EventArgs e) {

            // create a string builder so we can efficiently compose HTML
            StringBuilder builder = new StringBuilder();

            ////////////////////////////////
            // deal with the numbers list //
            ////////////////////////////////

            // create the HTNML list items for the numeric list
            for (int i = 0; i < 4; i++) {
                builder.AppendFormat("<li>{0}</li>\n", i);
            }

            // set the content of the number list
            numberList.InnerHtml = builder.ToString();

            ///////////////////////////////
            // deal with the things list //
            ///////////////////////////////

            // clear the StringBuilder so we can use it again
            builder.Clear();
            // append the string
            builder.AppendLine("Here are some things I like to do:");
            // append the list and the list items
            builder.AppendLine("<ol>");
            foreach (string str in new string[] {"Swim", "Cycle", "Run"}) {
                builder.AppendFormat("<li>{0}</li>\n", str);
            }
            builder.AppendLine("</ol>");
            // set the contents of the div element
            thingsListDiv.InnerHtml = builder.ToString();

            /////////////////////////
            // deal with the image //
            /////////////////////////
            image.Src = "/Images/triathlon.png";
            image.Alt = "Triathlon Symbols";

            ////////////////////////
            // deal with the link //
            ////////////////////////
            secondPageLink.HRef = "SecondPage.html";
            secondPageLink.InnerHtml = "This is a link to another page";
        }
    }
}