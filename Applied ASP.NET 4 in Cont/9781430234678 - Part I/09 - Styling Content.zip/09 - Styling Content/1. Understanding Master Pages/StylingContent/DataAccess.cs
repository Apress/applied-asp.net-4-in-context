﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace StylingContent {

    public class DataAccess {

        ///////////////////////////////
        // EventType related methods //
        //////////////////////////////

        public static string[] GetEventTypeNames(TrainingDataEntities contextParam) {
            return contextParam.EventTypes.Select(e => e.Name).ToArray();
        }

        /////////////////////////////
        // Athlete related methods //
        /////////////////////////////

        public static string[] GetAthleteNames(TrainingDataEntities contextParam) {
            return contextParam.Athletes.Select(e => e.Name).ToArray();
        }

        /////////////////////////////
        // Ranking related methods //
        /////////////////////////////

        public static RankingSet GetReferenceRanking(TrainingDataEntities contextParam,
            Event eventParam) {

            return new RankingSet(contextParam.GetReferenceRanking(eventParam.Type,
                eventParam.SwimTime, eventParam.CycleTime,
                eventParam.RunTime, eventParam.OverallTime));
        }

        public static RankingSet GetPersonalRanking(TrainingDataEntities contextParam,
            Event eventParam) {

            return new RankingSet(contextParam.GetPersonalRanking(eventParam.Athlete,
                eventParam.Type, eventParam.SwimTime, eventParam.CycleTime,
                eventParam.RunTime, eventParam.OverallTime));
        }

        ///////////////////////////
        // Event related methods //
        ///////////////////////////

        public static IEnumerable<Event> GetAllEvents(TrainingDataEntities contextParam) {
            return contextParam.Events;
        }

        public static IEnumerable<Event> GetEventsByType(TrainingDataEntities contextParam,
            string typeParam) {

            return contextParam.Events.Where(e => e.Type == typeParam).Select(e => e);
        }

        public static Event GetEventByID(TrainingDataEntities contextParam, int keyParam) {
            // query for the ID
            IEnumerable<Event> results = contextParam.Events
                                         .Where(e => e.ID == keyParam).Select(e => e);
            // as the ID is a primary key, there will be zero or one results
            return results.Count() == 1 ? results.First() : null;
        }

        public static void AddEvent(TrainingDataEntities contextParam,
            DateTime timeParam, string athleteParam, string typeParam,
            TimeSpan swimTimeParam, TimeSpan cycleTimeParam, TimeSpan runTimeParam) {

            // create the new entity object
            Event newEvent = new Event() {
                // set the date value in the event object
                Date = timeParam,
                // set the athlete and event type
                Athlete = athleteParam,
                Type = typeParam,
                // set the times
                SwimTime = swimTimeParam,
                CycleTime = cycleTimeParam,
                RunTime = runTimeParam,
                // calculate and set the overall time
                OverallTime = swimTimeParam + cycleTimeParam + runTimeParam
            };

            // add the Event object to the Events collection
            contextParam.Events.AddObject(newEvent);
            // save the change to the database
            contextParam.SaveChanges();
        }

        public static void UpdateEvent(TrainingDataEntities contextParam, int keyParam,
            DateTime dateParam, string athleteParam, string typeParam, TimeSpan swimTimeParam,
            TimeSpan cycleTimeParam, TimeSpan runTimeParam) {

            // query for the event with the specified key
            Event targetEvent = GetEventByID(contextParam, keyParam);

            // set the parameter values for the event
            if (targetEvent != null) {
                // update the event object properties
                targetEvent.Date = dateParam;
                targetEvent.Athlete = athleteParam;
                targetEvent.Type = typeParam;
                targetEvent.SwimTime = swimTimeParam;
                targetEvent.CycleTime = cycleTimeParam;
                targetEvent.RunTime = runTimeParam;
                targetEvent.OverallTime = swimTimeParam + cycleTimeParam + runTimeParam;
                // save the changes
                contextParam.SaveChanges();
            }
        }

        public static void DeleteEventByID(TrainingDataEntities contextParam, int keyParam) {
            // query for the object that has the specified key
            Event targetEvent = GetEventByID(contextParam, keyParam);

            // if there is a result from the query, perform a delete
            if (targetEvent != null) {
                contextParam.Events.DeleteObject(targetEvent);
                contextParam.SaveChanges();
            }
        }
    }

    public class RankingSet {
        public int SwimRank = -1;
        public int CycleRank = -1;
        public int RunRank = -1;
        public int OverallRank = -1;
        public int RankCount = -1;

        public RankingSet(IEnumerable<Ranking> sourceParam) {

            foreach (Ranking rank in sourceParam) {
                switch (rank.Activity) {
                    case "Swim":
                        SwimRank = rank.Pos ?? -1;
                        break;
                    case "Cycle":
                        CycleRank = rank.Pos ?? -1;
                        break;
                    case "Run":
                        RunRank = rank.Pos ?? -1;
                        break;
                    case "Overall":
                        OverallRank = rank.Pos ?? -1;
                        break;
                    case "Count":
                        RankCount = rank.Pos ?? -1;
                        break;
                }
            }
        }
    }
}
