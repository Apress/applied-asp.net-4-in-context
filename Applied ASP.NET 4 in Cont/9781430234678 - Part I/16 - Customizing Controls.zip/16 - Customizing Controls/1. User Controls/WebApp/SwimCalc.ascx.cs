﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;

namespace WebApp {

    public class SwimCalcEventArgs : EventArgs {
        private SwimCalcResult result;

        public SwimCalcEventArgs(SwimCalcResult res) {
            result = res;
        }

        public float Distance { get { return result.Distance; } }
        public float CalsBurned { get { return result.Calories; } }
        public float Pace { get { return result.Pace; } }
    }

public partial class SwimCalc : System.Web.UI.UserControl {
    public event EventHandler<SwimCalcEventArgs> CalcPerformed;
    private float[] lastInputs;

    [DefaultValue(false)]
    [Category("Behavior")]
    public bool EnableTextBoxAutoPostBack { get; set; }

    protected void Page_Load(object sender, EventArgs e) {

        // configure the TextBoxes based on the property value
        foreach (TextBox tb in new [] {LapsText, LengthText, MinText, CalsText}) {
            tb.AutoPostBack = EnableTextBoxAutoPostBack;
        }

        // define the int values that will hold the values from the input elements
        int laps, length, mins, cals;

        // try to get the values from the form elements as ints
        if (int.TryParse(LapsText.Text, out laps)
            && int.TryParse(LengthText.Text, out length)
            && int.TryParse(MinText.Text, out mins)
            && int.TryParse(CalsText.Text, out cals)) {

            float[] newinputs = new float[] { laps, length, mins, cals };

            // perform the calculation only if one of the inputs has changed
            if (lastInputs == null || !lastInputs.SequenceEqual(newinputs)) {

                // perform the calculation 
                SwimCalcResult result
                    = SwimCalculator.PerformCalculation(laps, length, mins, cals);
                // invoke the event
                OnCalcPerformed(new SwimCalcEventArgs(result));
                // update the set of inputs reflecting the last calculation
                lastInputs = newinputs;
            }
        }
    }

    protected virtual void OnCalcPerformed(SwimCalcEventArgs args) {
        EventHandler<SwimCalcEventArgs> handler = CalcPerformed;
        if (handler != null) {
            handler(this, args);
        }
    }

    protected override void OnInit(EventArgs e) {
        base.OnInit(e);
        Page.RegisterRequiresControlState(this);
    }

    protected override void LoadControlState(object savedState) {
        if (savedState != null) {
            lastInputs = (float[])savedState;
        }
    }

    protected override object SaveControlState() {
        return lastInputs;
    }
}
}