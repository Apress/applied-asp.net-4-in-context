﻿using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.Adapters;

namespace WebApp {
    public class RadioButtonListAdaptor : WebControlAdapter {

        protected override void RenderBeginTag(HtmlTextWriter writer) {

            writer.AddStyleAttribute(HtmlTextWriterStyle.BorderStyle, "solid");
            writer.AddStyleAttribute(HtmlTextWriterStyle.BorderColor, "black");
            writer.AddStyleAttribute(HtmlTextWriterStyle.BorderWidth, "thin");
            writer.AddStyleAttribute(HtmlTextWriterStyle.Width, "150px");
            writer.AddAttribute(HtmlTextWriterAttribute.Id, Control.ID);
            writer.AddAttribute(HtmlTextWriterAttribute.Name, Control.ID);
            writer.RenderBeginTag(HtmlTextWriterTag.Div);
        }

        protected override void RenderEndTag(HtmlTextWriter writer) {
            writer.RenderEndTag();
        }

        protected override void RenderContents(HtmlTextWriter writer) {
            
            RadioButtonList rblist = Control as RadioButtonList;
            if (rblist != null) {
                int counter = 0;
                foreach (ListItem item in rblist.Items) {
                 
                    // open the div element
                    writer.RenderBeginTag(HtmlTextWriterTag.Div);

                    // set the attributes for the input element
                    writer.AddAttribute(HtmlTextWriterAttribute.Id, Control.ID 
                        + "_" + counter);
                    writer.AddAttribute(HtmlTextWriterAttribute.Name, Control.ID);
                    writer.AddAttribute(HtmlTextWriterAttribute.Type, "radio");
                    writer.AddAttribute(HtmlTextWriterAttribute.Value, item.Value);
                    if (item.Selected) {
                        writer.AddAttribute(HtmlTextWriterAttribute.Checked, "checked");
                    }
                    // write the input element
                    writer.RenderBeginTag(HtmlTextWriterTag.Input);
                    writer.RenderEndTag();

                    // write the label element
                    writer.RenderBeginTag(HtmlTextWriterTag.Label);
                    writer.Write(item.Text);
                    writer.RenderEndTag();

                    // close the div element
                    writer.RenderEndTag();

                    // register the value as an expected data item
                    Page.ClientScript.RegisterForEventValidation(Control.ID, item.Value);

                    // increment the counter
                    counter++;
                }
            }   
        }
    }
}