﻿using System.Text;

namespace WebApp {
    public partial class Default : System.Web.UI.Page {



        protected void RadioButtonList1_SelectedIndexChanged(object sender, System.EventArgs e) {
            result.InnerText = RadioButtonList1.SelectedValue;
        }
    }
}