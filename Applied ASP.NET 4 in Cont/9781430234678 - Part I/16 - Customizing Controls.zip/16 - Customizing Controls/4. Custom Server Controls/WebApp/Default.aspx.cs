﻿using System.Text;

namespace WebApp {
    public partial class Default : System.Web.UI.Page {

        protected void HandleCalcPerformed(object sender, SwimCalcEventArgs e) {
            ResultsControl1.Distance = e.Distance.ToString("F0");
            ResultsControl1.Calories = e.CalsBurned.ToString("F0");
            ResultsControl1.Pace = e.Pace.ToString("F0");
        }
    }
}