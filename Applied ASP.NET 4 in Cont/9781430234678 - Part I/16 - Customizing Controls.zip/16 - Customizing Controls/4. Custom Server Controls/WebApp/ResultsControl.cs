﻿using System.ComponentModel;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApp {

    [ToolboxData("<{0}:ResultsControl runat=server></{0}:ResultsControl>")]
    public class ResultsControl : WebControl {

        [Category("Appearance")]
        [DefaultValue("0")]
        public string Distance { get; set; }

        [Category("Appearance")]
        [DefaultValue("0")]
        public string Calories { get; set; }

        [Category("Appearance")]
        [DefaultValue("0")]
        public string Pace { get; set; }

        [Browsable(false)]
        public override Color BackColor { get; set; }
        [Browsable(false)]
        public override Color ForeColor { get; set; }

        protected override void RenderContents(HtmlTextWriter output) {

            if (!string.IsNullOrEmpty(CssClass)) {
                output.AddAttribute(HtmlTextWriterAttribute.Class, CssClass);
            }
            output.RenderBeginTag("div");

            output.RenderBeginTag("div");
            output.Write(string.Format("Distance: {0}", Distance));
            output.RenderEndTag();

            output.RenderBeginTag("div");
            output.Write(string.Format("Calories: {0}", Calories));
            output.RenderEndTag();

            output.RenderBeginTag("div");
            output.Write(string.Format("Pace: {0}", Pace));
            output.RenderEndTag();

            output.RenderEndTag();
        }
    }
}
