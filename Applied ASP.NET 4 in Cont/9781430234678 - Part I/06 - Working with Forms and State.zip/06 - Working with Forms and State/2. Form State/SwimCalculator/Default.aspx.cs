﻿using System;
using System.Text;
using SwimCalculator.Calculations;

namespace SwimCalculator {

    public partial class Default : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) {

            if (IsPostBack) {
                // define the int values that will hold the values from the input elements
                int laps, length, mins, cals;

                // try to get the values from the form elements as ints
                if (int.TryParse(lapsInput.Value, out laps)
                    && int.TryParse(lengthInput.Value, out length)
                    && int.TryParse(minsInput.Value, out mins)
                    && int.TryParse(calsInput.Value, out cals)) {

                    // all of the input values were successfully converted to int values
                    try {

                        // perform the calculation
                        SwimCalcResult calcResult 
                            = SwimCalc.PerformCalculation(laps, length, mins, cals);

                        // - compose the results
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.AppendFormat("<p>Distance: {0:F2} miles</p>", 
                            calcResult.Distance);
                        stringBuilder.AppendFormat("<p>Calories Burned: {0:F0}</p>", 
                            calcResult.Calories);
                        stringBuilder.AppendFormat("<p>Pace : {0:F0} sec/lap</p>", 
                            calcResult.Pace);

                        // set the results text
                        results.InnerHtml = stringBuilder.ToString();

                    } catch (ArgumentOutOfRangeException) {
                        results.InnerText = "Error: parameter out of range";
                    }

                } else {
                    // at least one of the input values could not be converted to an int
                    results.InnerText = "Error: could not process input values";
                }
            }

            // set the values for the input fields    
            lapsInput.Value = "1";
            lengthInput.Value = "20";
            minsInput.Value = "60";
            calsInput.Value = "1070";
        }
    }
}